import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from src.main import app
from src.database import get_db, Base

# Use in-memory SQLite for tests
TEST_DATABASE_URL = "sqlite:///./test.db"
engine = create_engine(TEST_DATABASE_URL, connect_args={"check_same_thread": False})
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def override_get_db():
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()

app.dependency_overrides[get_db] = override_get_db

@pytest.fixture(autouse=True)
def setup_db():
    Base.metadata.create_all(bind=engine)
    yield
    Base.metadata.drop_all(bind=engine)

client = TestClient(app)

# ── Unit Tests ──────────────────────────────────────────────

def test_password_hashing():
    from src.auth import hash_password, verify_password
    password = "mysecretpassword"
    hashed = hash_password(password)
    assert hashed != password
    assert verify_password(password, hashed)

def test_invalid_password_does_not_match():
    from src.auth import hash_password, verify_password
    hashed = hash_password("correctpassword")
    assert not verify_password("wrongpassword", hashed)

def test_create_access_token():
    from src.auth import create_access_token
    token = create_access_token(data={"sub": "testuser"})
    assert isinstance(token, str)
    assert len(token) > 0

# ── API Tests ───────────────────────────────────────────────

def test_register_user():
    response = client.post("/auth/register", json={
        "username": "testuser",
        "email": "test@example.com",
        "password": "password123"
    })
    assert response.status_code == 201
    data = response.json()
    assert data["username"] == "testuser"
    assert data["role"] == "user"

def test_register_duplicate_username():
    client.post("/auth/register", json={
        "username": "testuser",
        "email": "test@example.com",
        "password": "password123"
    })
    response = client.post("/auth/register", json={
        "username": "testuser",
        "email": "other@example.com",
        "password": "password123"
    })
    assert response.status_code == 400

def test_login_success():
    client.post("/auth/register", json={
        "username": "testuser",
        "email": "test@example.com",
        "password": "password123"
    })
    response = client.post("/auth/login", json={
        "username": "testuser",
        "password": "password123"
    })
    assert response.status_code == 200
    assert "access_token" in response.json()

def test_login_wrong_password():
    client.post("/auth/register", json={
        "username": "testuser",
        "email": "test@example.com",
        "password": "password123"
    })
    response = client.post("/auth/login", json={
        "username": "testuser",
        "password": "wrongpassword"
    })
    assert response.status_code == 401

def get_token(username="testuser", email="test@example.com", password="password123"):
    client.post("/auth/register", json={
        "username": username,
        "email": email,
        "password": password
    })
    response = client.post("/auth/login", json={
        "username": username,
        "password": password
    })
    return response.json()["access_token"]

def test_create_task():
    token = get_token()
    response = client.post("/tasks/", json={
        "title": "My first task",
        "description": "Test description",
        "status": "pending"
    }, headers={"Authorization": f"Bearer {token}"})
    assert response.status_code == 201
    assert response.json()["title"] == "My first task"

def test_get_tasks():
    token = get_token()
    client.post("/tasks/", json={"title": "Task 1"}, headers={"Authorization": f"Bearer {token}"})
    response = client.get("/tasks/", headers={"Authorization": f"Bearer {token}"})
    assert response.status_code == 200
    assert len(response.json()) == 1

def test_update_task():
    token = get_token()
    create = client.post("/tasks/", json={"title": "Old title"}, headers={"Authorization": f"Bearer {token}"})
    task_id = create.json()["id"]
    response = client.put(f"/tasks/{task_id}", json={"title": "New title", "status": "completed"},
                          headers={"Authorization": f"Bearer {token}"})
    assert response.status_code == 200
    assert response.json()["title"] == "New title"
    assert response.json()["status"] == "completed"

def test_delete_task():
    token = get_token()
    create = client.post("/tasks/", json={"title": "To delete"}, headers={"Authorization": f"Bearer {token}"})
    task_id = create.json()["id"]
    response = client.delete(f"/tasks/{task_id}", headers={"Authorization": f"Bearer {token}"})
    assert response.status_code == 204

def test_unauthorized_access():
    response = client.get("/tasks/")
    assert response.status_code == 401

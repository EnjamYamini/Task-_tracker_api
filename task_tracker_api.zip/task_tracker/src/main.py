from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from src.database import engine
from src import models
from src.routes_auth import router as auth_router
from src.routes_users import router as users_router
from src.routes_tasks import router as tasks_router

models.Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="User Management & Task Tracker API",
    description="Backend Hiring Assignment - FastAPI + SQLite",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth_router)
app.include_router(users_router)
app.include_router(tasks_router)

@app.get("/")
def root():
    return {"message": "Task Tracker API is running!"}
